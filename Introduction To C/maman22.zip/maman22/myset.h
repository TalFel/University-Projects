#ifndef SET_H
#define SET_H

void act(char [], int);
void clear(char []);

#endif
