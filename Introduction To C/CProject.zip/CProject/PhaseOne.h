#ifndef PHASE_ONE_H
#define PHASE_ONE_H

#include <stdio.h>
#include <stdlib.h>
#include "Util.h"

RET_STATUS PhaseOneMain();
void FreePhaseOneHead();

#endif
