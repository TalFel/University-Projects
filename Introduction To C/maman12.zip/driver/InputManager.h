#ifndef InputManager_H
#define InputManager_H
int checkInput(int strlength, int ind1, int ind2, int len);
int containsOnlyNumbers(char ind[]);
void getInput(char str[]);
int getActualSize(char str[]);
void getStrInput(char str[], int maxLen);
#endif
