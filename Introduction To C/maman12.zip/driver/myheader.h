#ifndef MY_BCMP_H
#define MY_BCMP_H
int my_bcmp2 (const void *b1, const void *b2, int len);
#endif
