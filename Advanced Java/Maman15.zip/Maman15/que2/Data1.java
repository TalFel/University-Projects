//saiif 1.
public class Data1 extends Data {
    public Data1 (int x, int y){
        super(x, y);
    }
    @Override
    public int getDiff(){
        return super.getDiff();
    }
    @Override
    public void update(int dx, int dy){
        super.update(dx, dy);
    }
}
