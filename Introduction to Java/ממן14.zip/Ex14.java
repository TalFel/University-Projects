public class Ex14
{
    /**
     * question 1a - 3, 5;
     */
    /**
     * @param m the speciel sorted 2d array
     * @param val to search in m
     * @return true if val is in m
     * the time complexity is O(n):
     * the loops repeats 2n times at the most =O(n)
     * the memory compplexity is O(1):
     * there are 2 new variables =O(1)
     */
    public static boolean findValWhat(int [][] m, int val){
        int row = m.length - 1; int col = 0;
        while(row > -1 && col < m.length){
            if(m[row][col] == val) return true;
            if(m[row][col] > val) row--;
            else col++;
        }
        return false;
    }
    /**
     * @param m the speciel sorted 2d array
     * @param val to search in m
     * @return true if val is in m
     * the time complexity is O(n):
     * the first loop repeats n times and so does the second =O(n)
     * the memory compplexity is O(1):
     * there are 3 new variables =O(1)
     */
    public static boolean findValTest(int [][] m, int val){
        int temp = 0;
        for(int i = 0; i<m.length; i++){
            if(m[i][0] <= val){
                temp = i;
            }
        }
        if(temp == m.length - 1) temp--;
        for(int i = 0; i < m[0].length; i++){
            if(m[temp][i] == val) return true;
            if(m[temp+1][i] == val) return true;
        }
        return false;
    }
    /**
     * @param a 1d array
     * @return the total amount of rising numbers sequences
     * the time complexity is O(n):
     * the loop repeats n times =O(n)
     * the memory compplexity is O(1):
     * there are 3 new variables =O(1)
     */
    public static int strictlyIncreasing (int[] a){
        int tot = 0; // O(1) memory
        int templen = 1; //O(1) memory
        //loops a.length-1 times => O(a.length) run time
        for(int i = 0; i < a.length - 1; i++){ //O(1) memory
            //O(1) run time
            if(a[i] < a[i+1]){
                templen++;
            }
            //O(1) run time
            if(!(a[i] < a[i+1]) || i == a.length - 2){
                if(templen != 1){
                    tot+= templen*(templen-1)/2;
                }
                templen = 1;
            }
        }
        return tot;
    }
    /**
     * @param arr the array
     * @return the max length of the sequence
     * total runtime of O(n) (the other recursive functions)
     */
    public static int longestFlatSequence (int[] arr){
        if(arr.length < 2) return 1;
        return longestFlatSequence(arr, 0);
    }
    /**
     * @param arr the array
     * @param i the current index the func checks
     * @return the max length of the sequence
     */
    public static int longestFlatSequence (int[] arr, int i){
        //exit statment - last index
        if(i == arr.length - 1) return 1;
        //returns the max of the recursion and the lengthFlat of this index
        return Math.max(lengthFlat(arr, i, 0, 0, -1), longestFlatSequence(arr, i+1));
    }
    /**
     * @param arr the array
     * @param index the current index the func checks
     * @param a the first number in the sequence
     * @param b the second number in the sequence
     * @param len the length of the sequence
     * @return the length of the sequence
     */
    public static int lengthFlat (int[] arr, int index, int a, int b, int len){
        //index out of bound
        if(index == arr.length){
            return len;
        }
        //initializing a&b
        if(len == -1){
            if(index == arr.length - 1) return 1;
            a = arr[index];
            b = arr[index + 1];
            return lengthFlat(arr, index + 2, a, b, 2);
        }
        //in case that a=b
        if(a==b){
            if(arr[index]!=a) b = arr[index];
        }
        //arr[index] not valid
        if(arr[index] != a && arr[index] != b){
            //different from a or b
            return len;
        }
        //valid
        return lengthFlat(arr, index + 1, a, b, len + 1);
    }

    public static int findMaximum(int[][] mat){
        if(mat[0][0] == -1) return -1;
        return findMaximum(mat, 0, 0);
    }
    public static int findMaximum(int[][] mat, int row, int col){
        //index out of bound
        if(row == mat.length || col == mat[0].length || row == -1 || col == -1) return 0;
        //current square is -1
        if(mat[row][col] == -1) return 0;
        
        int op1; int op2; int temp;
        //option 1 - down
        op1 = findMaximum(mat, row+1, col);

        if(row % 2 == 0){
            //this label is now illigal
            temp = mat[row][col];
            mat[row][col] = -1;
            //option 2 - right
            op2 = findMaximum(mat, row, col + 1);
            //returns the label back
            mat[row][col] = temp;
            //returns the max of both
            //System.out.println("even row: " + row + " col: " + col + " op1: " + op1 + " op2: " + op2);
            return Math.max(op1, op2) + temp;
        }
        else{
            //this label is now illigal
            temp = mat[row][col];
            mat[row][col] = -1;
            //option 2 - left
            op2 = findMaximum(mat, row, col - 1);
            //returns the label back
            mat[row][col] = temp;
            //returns the max of both
            //System.out.println("odd row: " + row + " col: " + col + " op1: " + op1 + " op2: " + op2);
            return Math.max(op1, op2) + temp;
        }
    }
}
