/**
 * Maman 12
 * @author Tal Feldman
 * @version 07/04/2022
 */
public class Time1
{
    private int _hour;
    private int _minute;
    
    final int MAX_MINUTES = 59; // max minutes in hour
    final int MAX_HOURS = 23; // max hours in day
    final int MIN_HOURS = 0; // min hours in day
    final int MIN_MINUTES = 0; // min minutes in hour
    final int MINUTES_IN_HOUR = 60; // minutes in an hour
    final int MINS_IN_DAY = 1440; // minutes in a day
    
    /**
     * Constructs a Time1 object. Construct a new time instance with the specified hour and minute . hour should be between 0-23, otherwise it should be set to 0. minute should be between 0-59, otherwise it should be set to 0.
     * @param h the hour of the time
     * @param m the minute of the time
     */
    
    public Time1(int h, int m){
        if(h < MIN_HOURS || h > MAX_HOURS){
            _hour = MIN_HOURS;
        }
        else{
            _hour = h;
        }
        if(m < 0 || m > MAX_MINUTES){
            _minute = MIN_MINUTES;
        }
        else{
            _minute = m;
        }
    }
    /**
     * Copy constructor for Time1. Construct a time with the same instance variables as another time.
     * @param other The time object from which to construct the new time
     */
    public Time1 (Time1 other){
        _hour = other._hour;
        _minute = other._minute;
    }
    /**
     * Returns the hour of the time.
     * @return The hour of the time
     */
    public int getHour(){
        return _hour;
    }
    /**
     * Returns the minute of the time.
     * @return The minute of the time
     */
    public int getMinute(){
        return _minute;
    }
    /**
     * Changes the hour of the time. If an illegal number is received hour will be unchanged
     * @param num The new hour
     */
    public void setHour(int num){
        if(num <= MAX_HOURS && num >= MIN_HOURS){
            _hour = num;
        }
    }
    /**
     * Changes the minute of the time. If an illegal number is received minute will be unchanged
     * @param num - The new minute
     */
    public void setMinute(int num){
        if(num <= MAX_MINUTES && num >= MIN_MINUTES){
            _minute = num;
        }
    }
    /**
     * Return a string representation of this time (hh:mm).
     * @return String representation of this time (hh:mm).
     */
    public String toString(){
        String m = Integer.toString(this._minute);
        String h = Integer.toString(this._hour);
        String time = "";
        
        if(h.length() == 1) h = "0" + String.valueOf(_hour);
        if(m.length() == 1) m = "0" + String.valueOf(_minute);
        
        time += String.valueOf(h) + ":" + String.valueOf(m);
        return time;
    }
    /**
     * Return the amount of minutes since midnight
     * @return amount of minutes since midnight.
     */
    public int minFromMidnight(){
        int mins = MIN_MINUTES;
        mins = _hour *MINUTES_IN_HOUR + _minute;
        return mins;
    }
    /**
     * Check if the received time is equal to this time.
     * @param other The time to be compared with this time
     * @return True if the received time is equal to this time
     */
    public boolean equals (Time1 other){
        int h1 = other._hour;
        int m1 = other._minute;
        if(h1 == _hour && m1 == _minute){
            return true;
        }
        return false;
    }
    /**
     * Check if this time is before a received time
     * @param other The time to check if this point is before
     * @return True if this time is before other time
     */
    public boolean before (Time1 other){
        if(other._hour > _hour){
            return true;
        }
        else if(other._hour == _hour){
            if(other._minute > _minute){
                return true;
            }
        }
        return false;
    }
    /**
     * Check if this time is after a received time.
     * @param other The time to check if this point is after
     * @return True if this time is after other time
     */
    public boolean after (Time1 other){
        return (other.before(this));
    }
    /**
     * Calculates the difference (in minutes) between two times. Assumption: this time is after other time.
     * @param other The time to check the difference to
     * @return int difference in minutes
     * 
     */
    public int difference(Time1 other){
        return ((_hour - other._hour)*MINUTES_IN_HOUR + _minute - other._minute);
    }
    /**
     * Copy current object and add requested minutes to new object.
     * @param num The minutes need to add.
     * @return new update Time1 object.
     */
    public Time1 addMinutes(int num){

        int mins = this.minFromMidnight() + num;
        if(mins<MIN_MINUTES){
            mins = MINS_IN_DAY + (mins % -MINS_IN_DAY);
        }
        else{
            mins = mins % MINS_IN_DAY;
        }
        Time1 temp = new Time1(mins/MINUTES_IN_HOUR, mins%MINUTES_IN_HOUR);
        return temp;
    }
}
