/**
 * Maman 12
 * 
 * @author Tal Feldman
 * @version 07/04/2022
 */
public class Flight
{
    private String _origin; // the origin of the flight
    private String _destination; // the destination of the flight
    private Time1 _departure; // the departure time of the flight
    private int _flightDuration; // the duration of the flight
    private int _noOfPassengers; // the number of passengers on the flight
    private boolean _isFull; // true if the flight is full
    private int _price; // the price for ticket
    
    final int MAX_CAPACITY = 250; // the max capacity of a flight
    final int MIN_CAPACITY = 0; // the min capacity of a flight
    final int MIN_DURATION = 0; // the min duration of a flight
    final int MIN_PRICE = 0; // the min price of a ticket
    
    /**
     * Constructor for a Flight object
     *@param dest The city the flight lands at.
     *@param origin The city the flight leaves from.
     *@param depHour the departure hour (should be between 0-23).
     *@param depMinute The departure minute (should be between 0-59).
     *@param durTimeMinutes The duration time in minutes(should not be negative).
     *@param noOfPass The number of passengers (should be between 0-maximum capacity).
     *@param price The price (should not be negative).
     */
    public Flight(String origin, String dest,  int depHour, int depMinute, int durTimeMinutes, int noOfPass, int price){
        if (noOfPass >= MAX_CAPACITY){
            _noOfPassengers = MAX_CAPACITY;
            _isFull = true;
        }
        else{
            if(noOfPass < MIN_CAPACITY)
                _noOfPassengers = MIN_CAPACITY;
            else
                _noOfPassengers = noOfPass;
            _isFull = false;
        }
        
        if(durTimeMinutes < MIN_DURATION)
            _flightDuration = MIN_DURATION;
        else
            _flightDuration = durTimeMinutes;
        
        if(price < MIN_PRICE)
            _price = MIN_PRICE;
        else
            _price = price;
        
        _departure = new Time1(depHour, depMinute);
        _origin = origin;
        _destination = dest;
    }
    /**
     *Copy constructor for a Flight object
     *@param other The Flight object from which to construct the new Flight 
     */
    public Flight(Flight other){
        _origin = other._origin;
        _destination = other._destination;
        _departure = other._departure;
        _flightDuration = other._flightDuration;
        _noOfPassengers = other._noOfPassengers;
        _isFull = other._isFull;
        _price = other._price;
    }
    /**
     * Returns the flight origin
     * @return The flight origin
     */
    public String getOrigin(){
        return _origin;
    }
    /**
     * Returns the flight destination
     * @return the flight destination
     */
    public String getDestination(){
        return _destination;
    }
    /**
     * Returns the flight departure time
     * @return A copy of the flight departure time
     */
    public Time1 getDeparture(){
        return _departure;
    }
    /**
     * Returns the flight duration time in minutes
     * @return The flight duration
     */
    public int getFlightDuration(){
        return _flightDuration;
    }
    /**
     * Returns the number of passengers on the flight
     * @return The number of passengers
     */
    public int getNoOfPassengers(){
        return _noOfPassengers;
    }
    /**
     * Returns the number of passengers on the flight
     * @return True if the flight is full
     */
    public boolean getIsFull(){
        return _isFull;
    }
    /**
     * Returns the price of the flight
     * @return The price
     */
    public int getPrice(){
        return _price;
    }
    /**
     * Changes the flight's destination
     * @param dest The flight's new destination
     */
    public void setDestination(String dest){
        _destination = dest;
    }
    /**
     * Changes the flight's origin
     * @param origin The flight's new origin
     */
    public void setOrigin(String origin){
        _origin = origin;
    }
    /**
     * Changes the flight's departure time
     * @param departureTime The flight's new departure time
     */
    public void setDeparture(Time1 departureTime){
        _departure = departureTime;
    }
    /**
     * Changes the flight's duration time. If the parameter is negative the duration time will remain unchanged
     * @param departureTime The flight's new departure time
     */
    public void setFlightDuration(int durTimeMinutes){
        if(_flightDuration >= MIN_DURATION){
            _flightDuration = durTimeMinutes;
        }
    }
    /**
     * Changes the number of passengers. If the parameter is negative or larger than the maximum capacity the number of passengers will remain unchanged
     * @param noOfPass The new number of passengers
     */
    public void setNoOfPassengers(int noOfPass){
        if(noOfPass <= MAX_CAPACITY && noOfPass >= MIN_CAPACITY){
            _noOfPassengers = noOfPass;
            if(noOfPass == MAX_CAPACITY) _isFull = true;
        }
    }
    /**
     * Changes the flight price. If the parameter is negative the price will remain unchanged
     * @param price The new price
     */
    public void setPrice(int price){
        _price = price;
    }
    
    /**
     * Return a string representation of this flight (for example: "Flight from London to Paris departs at 09:24.Flight is full.").
     * @return String representation of this flight (for example: "Flight from London to Paris departs at 09:24.Flight is full.")
     */
    public String toString(){
        if(_isFull){
            return ("Flight from " + _origin + " to " + _destination + " departs at " + 
                _departure.toString() + ". Flight is full");
        }
        else{
            return ("Flight from " + _origin + " to " + _destination + " departs at " + 
                _departure.toString() + ". Flight is not full");
        }
    }
    /**
     * Check if the received flight is equal to this flight. Flights are considered equal if the origin, destination and departure times are the same
     * @param other The flight to be compared with this flight
     * @return True if the received flight is equal to this flight
     */
    public boolean equals(Flight other){
        if(_origin == other._origin && _destination == other._destination && _departure == other._departure
            && _flightDuration == other._flightDuration && _noOfPassengers == other._noOfPassengers
            && _isFull == other._isFull && _price == other._price){
            return true;
        }
        else{
            return false;
        }
    }
    /**
     * Returns the arrival time of the flight
     * @return The arrival time of this flight
     */
    public Time1 getArrivalTime(){
        Time1 temp = new Time1(_departure);
        return temp.addMinutes(_flightDuration);
    }
    /**
     * Add passengers to this flight. If the number of passengers exceeds he maximum capacity, no passengers are added and alse is returned. If the flight becomes full, the boolean attribute describing whether the flight if full becomes true
     * @param num The number of passengers to be added to this flight
     * @return True if the passengers were added to the flight
     */
    public boolean addPassengers(int num){
        if(num + _noOfPassengers > MAX_CAPACITY){
            return false;
        }
        else{
            _noOfPassengers += num;
            return true;
        }
    }
    /**
     * Check if this flight is cheaper than another flight
     * @param other The flight whose price is to be compared with this flight's price
     * @return True if this flight is cheaper than the received flight
     */
    public boolean isCheaper(Flight other){
        return (_price < other._price);
    }
    /**
     * Calculate the total price of the flight
     * @return The total price of the flight
     */
    public int totalPrice(){
        return _price*_noOfPassengers;
    }
    /**
     * Check if this flight lands before another flight. Note - the flights may land on different days, the method checks which flight lands first
     * @param other The flight whose arrival time to be compared with this flight's arrival time
     * @return True if this flight arrives before the received flight
     */
    public boolean landsEarlier(Flight other){
        return (this.getArrivalTime()).before(other.getArrivalTime());
    }
}
