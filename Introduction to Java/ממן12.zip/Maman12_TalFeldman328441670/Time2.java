public class Time2
{
    private int _minFromMid;
    
    final int MINS_IN_HOUR = 60; // minutes in hour
    final int HOURS_IN_DAY = 24; // minutes in day
    final int MIN_HOURS = 0; // min hours in a day
    final int MIN_MINUTES = 0; // min minutes in a day
    final int MINS_IN_DAY = 1440; // minutes in a day
    /**
     * Constructs a Time1 object. Construct a new time instance with the specified hour and minute . hour should be between 0-23, otherwise it should be set to 0. minute should be between 0-59, otherwise it should be set to 0.
     * @param h the hour of the time
     * @param m the minute of the time
     */
    public Time2(int h, int m){
        _minFromMid = h*MINS_IN_HOUR + m;
    }
    /**
     * Copy constructor for Time2. Construct a time with the same instance variables as another time.
     * @param other The time object from which to construct the new time
     */
    public Time2(Time2 other){
        _minFromMid = other._minFromMid;
    }
    /**
     * Returns the hour of the time.
     * @return The hour of the time
     */
    public int getHour(){
        return _minFromMid/MINS_IN_HOUR;
    }
    /**
     * Returns the minute of the time.
     * @return The minute of the time
     */
    public int getMinute(){
        return _minFromMid%MINS_IN_HOUR;
    }
    /**
     * Changes the hour of the time. If an illegal number is received hour will be unchanged
     * @param num The new hour
     */
    public void setHour(int num){
        if(num < HOURS_IN_DAY && num >= MIN_HOURS){
            _minFromMid = _minFromMid - this.getHour()*MINS_IN_HOUR + num*MINS_IN_HOUR;
        }
    }
    /**
     * Changes the minute of the time. If an illegal number is received minute will be unchanged
     * @param num - The new minute
     */
    public void setMinute(int num){
        if(num < MINS_IN_HOUR && num >= MIN_MINUTES){
            _minFromMid = _minFromMid - this.getMinute() + num;
        }
    }
    /**
     * Return the amount of minutes since midnight
     * @return amount of minutes since midnight.
     */
    public int minFromMidnight(){
        return _minFromMid;
    }
    /**
     * Check if the received time is equal to this time.
     * @param other The time to be compared with this time
     * @return True if the received time is equal to this time
     */
    public boolean equals(Time2 other){
        return (_minFromMid == other._minFromMid);
    }
    /**
     * Check if this time is before a received time
     * @param other The time to check if this point is before
     * @return True if this time is before other time
     */
    public boolean before(Time2 other){
        return (_minFromMid < other._minFromMid);
    }
    /**
     * Check if this time is after a received time.
     * @param other The time to check if this point is after
     * @return True if this time is after other time
     */
    public boolean after(Time2 other){
        return (other.before(this));
    }
    /**
     * Calculates the difference (in minutes) between two times. Assumption: this time is after other time.
     * @param other The time to check the difference to
     * @return int difference in minutes
     * 
     */
    public int difference(Time2 other){
        return (_minFromMid - other._minFromMid);
    }
    /**
     * Return a string representation of this time (hh:mm).
     * @return String representation of this time (hh:mm).
     */
    public String toString(){
        String h = String.valueOf(_minFromMid/MINS_IN_HOUR);
        String m = String.valueOf(_minFromMid%MINS_IN_HOUR);
        String time = "";
        if(h.length() == 1) h = "0" + h;
        if(m.length() == 1) m = "0" + m;
        time += h + ":" + m;
        return time;
    }
    /**
     * Copy current object and add requested minutes to new object.
     * @param num The minutes need to add.
     * @return new update Time1 object.
     */
    public Time2 addMinutes(int num){
        int tempMin = _minFromMid + num;
        if(tempMin < MIN_MINUTES) tempMin = MINS_IN_DAY + (tempMin % -MINS_IN_DAY);
        else tempMin = tempMin % MINS_IN_DAY;
        Time2 temp = new Time2(tempMin/MINS_IN_HOUR, tempMin%MINS_IN_HOUR);
        return temp;
    }
}
