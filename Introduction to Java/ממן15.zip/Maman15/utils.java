
/**
 * Write a description of class utils here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class utils
{
    // instance variables - replace the example below with your own
    private int x;
    public static int _counter;
    public static boolean _exitOnError = true;

    /**
     * Constructor for objects of class utils
     */
    public utils()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
    
    public static void printMessage(String str)
    {
        System.out.print(String.valueOf(_counter) + "." + str + "\n");
       
    }
    public static void printError(String str)
    {
        System.out.print(String.valueOf(_counter) + "." + str + "\n");
        printStack();
        if (_exitOnError)
            System.exit(1);
    }
    public static void printStack()
    {
        for (StackTraceElement ste : Thread.currentThread().getStackTrace()) 
        {
            System.out.println(ste);
        }
    }    
    public static void verifyBool(boolean val)
    {
        _counter++;
        if (val) return;
        printError("error verifyBool");
    }    
}
