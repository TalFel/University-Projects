
/**
 * Write a description of class Set here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Set
{
    private IntNode _first;
    private int _numOfElements;//TODO rename to num
    
    public Set(){
        _first = null;
        _numOfElements = 0;
    }
    /**
     * @param x the node to add
     * the function adds x to the set if no x already exists.
     * the function inserts it in way that the set will stay sorted 
     */
    public void addToSet (int x){
        if(x%2 == 0 || x < 0) return;
        if(_first == null){
            IntNode newX = new IntNode(x, null);
            _first = newX;
            _numOfElements++;
            return;
        }
        if(_first.getValue()>x){
            IntNode newX = new IntNode(x, _first);
            _first = newX;
            _numOfElements++;
            return;
        }
        IntNode temp = _first;
        for(; temp.getNext()!= null; temp = temp.getNext()){
            if(temp.getNext().getValue() > x && temp.getValue() < x){
                IntNode newX = new IntNode(x, temp.getNext());
                temp.setNext(newX);
                _numOfElements++;
                return;
            }
        }
        if(temp.getValue()<x){
            IntNode newX = new IntNode(x, null);
            temp.setNext(newX);
            _numOfElements++;
        }
    }
    /**
     * @param x the node to remove
     * the function removes x from the set.
     */
    public void removeFromSet (int x){
        if(x%2 == 0 || x < 0) return;
        IntNode temp = _first, before = null;
        if(temp.getValue() == x){
            if(numOfElements() == 1) _first = null;
            else{
                _first = _first.getNext();
            }
            _numOfElements--;
            return;
        }
        for(; temp.getNext() != null && temp.getValue() <= x; before = temp, temp = temp.getNext()){
                if(temp.getValue() == x){
                    before.setNext(temp.getNext());
                    _numOfElements--;
                    return;
                }
        }
        if(temp.getValue() == x){
            before.setNext(null);
            _numOfElements--;
        }
    }
    /**
     * @return a string of the array
     * the function makes a string of the array. for example:
     * {1, 3, 5, 19, 111}
     */
    public String toString(){
        if(isEmpty()) return "{}";
        String str = "{" + _first.getValue();
        for(IntNode temp = _first.getNext(); temp!= null; temp = temp.getNext()){
            str +=  "," + temp.getValue() ;
        }
        return (str+"}");
    }
    /**
     * @return true if the set is empty and false otherwise
     */
    public boolean isEmpty (){
        return (numOfElements() == 0);
    }
    /**
     * @param num a value to check if it is in the set
     * @return true if num is a member of the set
     */
    public boolean isMember (int num){
        if(isEmpty()) return false;
        for(IntNode temp = _first; temp!= null && temp.getValue() <= num; temp = temp.getNext()){
            if(temp.getValue() == num) return true;
        }
        return false;
    }
    /**
     * @param other the other set to compare
     * @return true if the sets are eqaul
     */
    public boolean equals (Set other){
        if(numOfElements()!= other.numOfElements()) return false;
        for(IntNode temp1 = _first, temp2 = other._first; temp1!= null && temp2 != null; temp1 = temp1.getNext(), temp2 = temp2.getNext()){
            if(temp1.getValue() != temp2.getValue()) return false;
        }
        return true;
    }
    /**
     * @return the number of elements in the set
     */
    public int numOfElements (){
        return _numOfElements;
    }
    /**
     * @param other the subset to check
     * @return if other is a subset of the set
     */
    public boolean subSet (Set other){
        if(other.numOfElements() > numOfElements()) return false;
        if(other.isEmpty()) return true;
        IntNode temp2 = other._first;
        for(IntNode temp1 = _first; temp1!=null&& temp2!=null; temp1 = temp1.getNext()){
            if(temp1.getValue()==temp2.getValue()){
                temp2 = temp2.getNext();
                if(temp2 == null) return true;
            }
        }
        return false;
    }
    public Set intersection (Set other){
        Set set = new Set();
        for(IntNode temp1 = _first; temp1!= null; temp1 = temp1.getNext()){
            for(IntNode temp2 = other._first; temp2!= null && temp2.getValue() <= temp1.getValue(); temp2 = temp2.getNext()){
                if(temp1.getValue() == temp2.getValue()) set.addToSet(temp1.getValue());
            }
        }
        return set;
    }
    public Set union (Set other){
        Set set = new Set();
        for(IntNode temp1 = _first; temp1!= null; temp1 = temp1.getNext()){
            set.addToSet(temp1.getValue());
        }
        for(IntNode temp2 = other._first; temp2!= null; temp2 = temp2.getNext()){
            set.addToSet(temp2.getValue());
        }
        return set;
    }
    public Set difference (Set other){
        Set set = new Set();
        for(IntNode temp1 = _first; temp1!= null; temp1 = temp1.getNext()){
            if(!other.isMember(temp1.getValue())){
                set.addToSet(temp1.getValue());
            }
        }
        return set;
    }
}
