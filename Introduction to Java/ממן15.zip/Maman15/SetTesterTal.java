public class SetTesterTal {
    
    
    public static int _counter;
    public static boolean _exitOnError = true;
    public static void printMessage(String str)
    {
        System.out.print(String.valueOf(_counter) + "." + str + "\n");
       
    }
    public static void printError(String str)
    {
        System.out.print(String.valueOf(_counter) + "." + str + "\n");
        printStack();
        if (_exitOnError)
            System.exit(1);
    }
    public static void verifyList(Set set, int len, String listStr)
    {
        _counter++;
        if (len == 0 && !set.isEmpty()) printError("error expected len="+String.valueOf(len) + " but len="+String.valueOf(set.numOfElements()));
        if (set.numOfElements() != len) printError("error expected len="+String.valueOf(len) + " but len="+String.valueOf(set.numOfElements()));
        if (!(set.toString().equals(listStr))) printError("error expected list="+ listStr + " but list="+set.toString());
    }    
    public static void printStack()
    {
        for (StackTraceElement ste : Thread.currentThread().getStackTrace()) 
        {
            System.out.println(ste);
        }
    }
    public static void verifyBool(boolean val, Set set)
    {
        _counter++;
        if (val) return;
        printError("error verifyBool " + ",list="+set.toString());
    }
    public static void verifyBool(boolean val, Set s1, Set s2)
    {
        _counter++;
        if (val) return;
        printError("\nerror verifyBool " + ",s1="+s1.toString() + ",s2=" + s2.toString());
    }
    public static void testConstruction()
    {
        /* constructor*/
        Set s1 = new Set();
        Set s2 = new Set();
        verifyList(s1, 0,"{}");
        verifyList(s2, 0,"{}");
        
    }
    public static void testAddToSet()
    {
        /* addToSet */
        System.out.print("\nTesting addToSet: ");
        Set  s1= new Set();
        s1.addToSet(4);//add odd number to empty list
        verifyList(s1, 0,"{}");
        s1.addToSet(3);
        verifyList(s1, 1,"{3}");
        s1.addToSet(3);//add same number again
        verifyList(s1, 1,"{3}");
        s1.addToSet(-1);//add negative
        verifyList(s1, 1,"{3}");
        s1.addToSet(2);//add odd number to not empty list
        verifyList(s1, 1,"{3}");
        s1.addToSet(7);//add bigger number in the end
        verifyList(s1, 2,"{3,7}");
        s1.addToSet(1);//adding smaller in head
        verifyList(s1, 3,"{1,3,7}");
        s1.addToSet(5);//add in the middle
        verifyList(s1, 4,"{1,3,5,7}");
        
    }
    public static void testIsEmpty()
    {
      /* isEmpty */
        System.out.print("\nTesting isEmpty: ");
        Set  s1 = new Set();
        verifyBool(s1.isEmpty(),s1);
        s1.addToSet(5);
        verifyBool(s1.isEmpty()==false, s1);

    }
    public static void testIsMember()
    {
      /* isMember */
        System.out.print("\nTesting isMember: ");
        Set  s1 = new Set();
        s1.addToSet(5);
        verifyBool(s1.isMember(3)==false,s1);
        verifyBool(s1.isMember(4)==false,s1);
        verifyBool(s1.isMember(5)==true,s1);
        verifyBool(s1.isMember(7)==false,s1);
        verifyBool(s1.isMember(-1)==false,s1);
  
    }
    public static void testRemoveFromSet()
    {
       
        /* removeFromSet */
        System.out.print("\nTesting removeFromSet: ");
        Set  s1 = new Set();
        s1.addToSet(5);
        s1.removeFromSet(4);//remove odd number
        verifyList(s1,1,"{5}");
        s1.removeFromSet(7);//remove not exist item
        verifyList(s1,1,"{5}");
        s1.removeFromSet(5);//remove last item
        verifyList(s1, 0,"{}");
        s1.addToSet(3);
        s1.addToSet(5);
        s1.addToSet(7);
        s1.addToSet(11);
        s1.addToSet(15);
        s1.removeFromSet(3);//remove first
        verifyList(s1, 4,"{5,7,11,15}");
        s1.removeFromSet(15);//remove last
        verifyList(s1, 3,"{5,7,11}");
        s1.removeFromSet(4);//remove odd
        verifyList(s1, 3,"{5,7,11}");
        s1.removeFromSet(15);//remove not exist
        verifyList(s1, 3,"{5,7,11}");
        s1.removeFromSet(7);//remove middle
        verifyList(s1, 2,"{5,11}");
        
    }
    public static void testEquals()
    {
         /* equals */
        System.out.print("\nTesting equals: ");
    
        //empty list
        Set  s1 = new Set();
        Set  s2 = new Set();
        verifyBool(s1.equals(s2)==true,s1,s2);
        
        //different len (one empty)
        s1 = new Set();
        s1.addToSet(3);
        verifyBool(s1.equals(s2)==false,s1,s2);
        
        //different len
        s1 = new Set();
        s1.addToSet(3);
        s2 = new Set();
        s2.addToSet(3);
        s2.addToSet(5);
        verifyBool(s1.equals(s2)==false,s1,s2);
        
        //same len, same content - 1 items
        s1 = new Set();
        s1.addToSet(3);
        s2 = new Set();
        s2.addToSet(3); 
        verifyBool(s1.equals(s2)==true,s1,s2);
        
        //same len, different content
        s1 = new Set();
        s2.addToSet(3);
        s2 = new Set();
        s2.addToSet(5);
        verifyBool(s1.equals(s2)==false,s1,s2);
        
        //same list different order
        s1 = new Set();
        s1.addToSet(3);
        s1.addToSet(5);
        s2 = new Set();
        s2.addToSet(5);
        s2.addToSet(3);
        verifyBool(s1.equals(s2)==true,s1,s2);        
        
    }
    public static void testSubSet()
    {
        /* subSet */
        System.out.print("Testing subSet: ");
        Set  s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(3);
        s1.addToSet(9);
        s1.addToSet(17);
        Set  s2 = new Set();
        s2.addToSet(1);
        
        verifyBool(s1.subSet(s2)==true,s1,s2);        
        
        verifyBool(s2.subSet(s1)==false,s1,s2);

        // same list
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(2);
        s1.addToSet(4);
        s2 = new Set();
        s2.addToSet(1);
        s2.addToSet(2);
        s2.addToSet(4);
        verifyBool(s1.subSet(s2)==true,s1,s2);        
        
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(2);
        s1.addToSet(4);
        s2 = new Set();
        s2.addToSet(1);
        s2.addToSet(4);
        verifyBool(s1.subSet(s2)==true,s1,s2);            

        //empty list
        s1 = new Set();
        s2 = new Set();
        verifyBool(s1.subSet(s2)==true,s1,s2);            
    }
    public static void testIntersetion()
    {
        /* intersection */
        System.out.print("Testing intersection: ");
        Set  s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(3);
        Set  s2 = new Set();
        s2.addToSet(7);
        s2.addToSet(3);
        Set s3 = s1.intersection(s2);
        Set expected_s3 = new Set();
        expected_s3.addToSet(3);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);  
        
        //empty list
        System.out.print("Testing intersection: ");
        s1 = new Set();
        s2 = new Set();
        s3 = s1.intersection(s2);
        expected_s3 = new Set();
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);          

        //same list
        System.out.print("Testing intersection: ");
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(2);
        s2 = new Set();
        s2.addToSet(1);
        s2.addToSet(2);
        s3 = s1.intersection(s2);
        expected_s3 = new Set();
        expected_s3.addToSet(1);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);  

        //nothing intersects
        System.out.print("Testing intersection: ");
        s1 = new Set();
        s1.addToSet(1);
        s2 = new Set();
        s2.addToSet(2);
        s3 = s1.intersection(s2);
        expected_s3 = new Set();
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3); 
        
        //same list
        System.out.print("Testing intersection: ");
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(2);
        s1.addToSet(3);
        s1.addToSet(4);
        s2 = new Set();
        s2.addToSet(1);
        s2.addToSet(2);
        s2.addToSet(3);
        s2.addToSet(5);
        s3 = s1.intersection(s2);
        expected_s3 = new Set();
        expected_s3.addToSet(1);
        expected_s3.addToSet(2);
        expected_s3.addToSet(3);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);        
    }
    public static void testUnion()
    {
        /* union */
        System.out.print("Testing union: ");
        Set s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(3);
        Set s2 = new Set();
        s2.addToSet(9);
        s2.addToSet(3);
        Set  s3 = s1.union(s2);
        Set expected_s3 = new Set();
        expected_s3.addToSet(3);
        s2.addToSet(1);
        s2.addToSet(3);
        s2.addToSet(9);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);       
        
        //different items
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(2);
        s2 = new Set();
        s2.addToSet(3);
        s2.addToSet(4);
        s3 = s1.union(s2);
        expected_s3 = new Set();
        expected_s3.addToSet(3);
        s2.addToSet(1);
        s2.addToSet(2);
        s2.addToSet(3);
        s2.addToSet(4);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);  
        
         //same items
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(2);
        s2 = new Set();
        s2.addToSet(1);
        s2.addToSet(2);
        s3 = s1.union(s2);
        expected_s3 = new Set();
        expected_s3.addToSet(3);
        s2.addToSet(1);
        s2.addToSet(2);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);          
        
        //empty set both
        s1 = new Set();
        s2 = new Set();
        s3 = s1.union(s2);
        expected_s3 = new Set();
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);          
        
        //one is empty set
        s1 = new Set();
        s1.addToSet(2)
        s2 = new Set();
        s3 = s1.union(s2);
        expected_s3 = new Set();
        expected_s3.addToSet(2);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);          
        
    }
    public static void testDiff()
    {
        /* difference */
        System.out.print("Testing difference: ");
        
        Set s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(3);
        Set s2 = new Set();
        s2.addToSet(1);
        s2.addToSet(7);
        s2.addToSet(3);
        Set  s3 = s1.difference(s2);
        Set expected_s3 = new Set();
        expected_s3.addToSet(7);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);        
        
        //all are different
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(3);
        s2 = new Set();
        s2.addToSet(2);
        s2.addToSet(7);
        s3 = s1.difference(s2);
        expected_s3 = new Set();
        expected_s3.addToSet(1);
        expected_s3.addToSet(2);
        expected_s3.addToSet(3);
        expected_s3.addToSet(7);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);        
        
        //empty
        s1 = new Set();
        s2 = new Set();
        s3 = s1.difference(s2);
        expected_s3 = new Set();
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3); 
        
        //diff in both
        s1 = new Set();
        s1.addToSet(1);
        s1.addToSet(3);
        s1.addToSet(5);
        s2 = new Set();
        s2.addToSet(3);
        s2.addToSet(5);
        s2.addToSet(7);
        s3 = s1.difference(s2);
        expected_s3 = new Set();
        expected_s3.addToSet(1);
        expected_s3.addToSet(7);
        verifyBool(expected_s3.equals(s3)==true,expected_s3,s3);        
        
    }
    public static void main(String[] args)
    {
        printMessage("\n^^ linaTest start");
        testConstruction();
        testAddToSet();
        testIsEmpty();
        testIsMember();         
        testRemoveFromSet();
        testEquals();
        testSubSet();
        testUnion();
        testDiff();
        
        printMessage("\nVV linaTest end");
            
    }
    
    
    private static String getOutputText(boolean result) {
        return result ? "Succees" : "Fail";
    }
}
