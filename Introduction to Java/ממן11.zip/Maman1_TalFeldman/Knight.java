import java.util.Scanner;
public class Knight
{
    public static void main (String [] args)
    {
        final int BOARD_MAX = 8;
        final int BOARD_MIN = 1;
        Scanner scan = new Scanner (System.in);
        System.out.println ("This program reads two integers which " +
        "represent the knight's location on the chess board: ");
        System.out.println ("Please enter the number of row");
        int row = scan.nextInt();
        System.out.println ("Please enter the number of column");
        int col = scan.nextInt();
        //checks if the input is legal
        if (row > 8 || col > BOARD_MAX){
            System.out.println ("input is illegal");
        }
        else{
            //prints the possible moves of the knight
            System.out.println ("Moves:");
            if(col + 1 <= BOARD_MAX){
                if(row + 2 <= BOARD_MAX)
                    System.out.println ((row + 2) + " " + (col + 1));
                if(row - 2 >= BOARD_MIN)
                    System.out.println ((row - 2) + " " +  (col + 1));
            }
            if(col + 2 <= BOARD_MAX){
                if(row + 1 <= BOARD_MAX)
                    System.out.println ((row + 1) + " " +  (col + 2));
                if(row - 1 >= BOARD_MIN)
                    System.out.println ((row - 1) + " " +  (col + 2));
            }
            if(col - 1 >= BOARD_MIN){
                if(row + 2 <= BOARD_MAX)
                    System.out.println ((row + 2) + " " +  (col - 1));
                if(row - 2 >= BOARD_MIN)
                    System.out.println ((row - 2) + " " +  (col - 1));
            }
            if(col - 2 >= BOARD_MIN){
                if(row + 1 <= BOARD_MAX)
                    System.out.println ((row + 1) + " " +  (col - 2));
                if(row - 2 >= BOARD_MIN)
                    System.out.println ((row - 1) + " " +  (col - 2));
            }
        }
        
    }
}