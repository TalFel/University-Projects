import java.util.Scanner;
import java.lang.Math;
import javax.swing.Box;

public class Chess
{
    public static void main (String [] args)
    {
        final char BISHOP = 'b';
        final char ROOK = 'r';
        final char KNIGHT = 'k';
        final int MAX_BOARD = 8;
        Scanner scan = new Scanner (System.in);
        System.out.println("Please enter the type"+
        " of the first chessman");
        char first = scan.next().charAt(0);
        System.out.println ("Please enter the number of row");
        int row1 = scan.nextInt();
        System.out.println ("Please enter the number of column");
        int col1 = scan.nextInt();
        System.out.println("Please enter the type"+
        " of the second chessman");
        char second = scan.next().charAt(0);
        System.out.println ("Please enter the number of row");
        int row2 = scan.nextInt();
        System.out.println ("Please enter the number of column");
        int col2 = scan.nextInt();
        String firstTool;
        String secondTool;
        //-------------
        switch(first){
            case BISHOP:
                firstTool = "bishop";
                break;
            case ROOK:
                firstTool = "rook";
                break;
            default:
                firstTool = "knight";
                break;
        }
        switch(second){
            case BISHOP:
                secondTool = "bishop";
                break;
            case ROOK:
                secondTool = "rook";
                break;
            default:
                secondTool = "knight";
                break;
        }
        //---------------------------------
        int tempx1, tempy1, tempx2, tempy2;
        boolean thretexist = false;
        //checks if input is leagal
        if(first == second)
            System.out.println("Chessmen should be different from each other");
        else if(row1 > MAX_BOARD || row2 > MAX_BOARD || col1 > MAX_BOARD || col2 > MAX_BOARD)
            System.out.println("Position is not legal");
        else if(row1 == row2 && col1 == col2)
            System.out.println("Chessmen positions should not be identical");
        //checks for threats
        else{
            //checks if the knight is threating the other tool
            if(first == KNIGHT)
            {
                if(Math.abs(row1-row2) + Math.abs(col1-col2) == 3 &&
                col1 != col2 &&  row1 != row2){
                    thretexist = true;
                    System.out.println(firstTool + " threats " + secondTool);
                }
            }
            if(second == KNIGHT)
            {
                if(Math.abs(row1-row2) + Math.abs(col1-col2) == 3 &&
                col1 != col2 &&  row1 != row2){
                    thretexist = true;
                    System.out.println(secondTool + " threats " + firstTool);
                }
            }
            //checks if the rook is threating the other tool
            if(first == ROOK){
                if(row1 == row2 || col1 == col2){
                    thretexist = true;
                    System.out.println(firstTool + " threats " + secondTool);
                }
            }
            if(second == ROOK){
                if(row1 == row2 || col1 == col2){
                    thretexist = true;
                    System.out.println(secondTool + " threats " + firstTool);
                }
            }
            //checks if the bishop is threating the other tool
            if(first == BISHOP){
                if(col1 - row1 == col2 - row2 || col1 + row1 == col2 + row2){
                    thretexist = true;
                    System.out.println(firstTool + " threats " + secondTool);
                }
            }
            if(second == BISHOP){
                if(col1 - row1 == col2 - row2 || col1 + row1 == col2 + row2){
                    thretexist = true;
                    System.out.println(secondTool + " threats " + firstTool);
                }
            }
            //if there is no threat it will enter here
            if (thretexist == false){
                System.out.println("no threat");
            }
        }
    }
}
