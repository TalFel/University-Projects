/**
 * Maman 13 Flight
 * @author Tal Feldman
 * @version 04/2022
 */
public class Airport
{   
    Flight[] _flightsSchedule; //The flight schedule of an airport
    int _noOfFlights; // Number of flights in the array
    String _city; // The city of the airport
    final int MAX_FLIGHTS = 200; // Max flights in the schedule
    
    /**
     * Constractor for an Airport object
     * @param city the airport's city
     */
    public Airport(String city){
        _city = city;
        _flightsSchedule = new Flight[MAX_FLIGHTS];
        _noOfFlights = 0;
    }
    /**
     * Adds a flight to the schedule.
     * @param f the flight to add
     */
    public boolean addFlight(Flight f){
        if(_noOfFlights == MAX_FLIGHTS || !(f.getOrigin().equals(_city) || 
            f.getDestination().equals(_city))){
            return false;
        }
        _flightsSchedule[_noOfFlights++] = f;
        return true;
    }
    /**
     * Removes a flight from the schedule and fills the hole in the array
     * @param f the flight to remove
     * @return true if was succesful and false otherwise
     */
    public boolean removeFlight(Flight f){
        int loc = -1;
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].equals(f)) loc = i;
        }
        if(loc == -1) return false;
        for(int i = loc; i < _noOfFlights - 1; i++){
            _flightsSchedule[i] = new Flight(_flightsSchedule[i+1]);
        }
        _flightsSchedule[_noOfFlights] = null;
        _noOfFlights--;
        return false;
    }
    /**
     * Returns the first flight from an origin
     * @param place the wanted origin
     * @return the first flight from the origin otherwise or null if the flight does'nt exist 
     */
    public Time1 firstFlightFromOrigin (String place){
        int min = -1;
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].getOrigin().equals(place)){
                min = i;
            }
        }
        if(min == -1) return null;
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].getOrigin() == place &&
                _flightsSchedule[i].getDeparture().before(_flightsSchedule[min].getDeparture()))
                    min = i;
        }
        return _flightsSchedule[min].getDeparture();
    }
    /**
     * Returns a string representation of the schedule
     * @return a string representation of the flight or null if there are no flights
     * For example:
     * The flights for airport Tel-Aviv today are:
     * Flight from Tel-Aviv to London departs at 12:00. Flight is full.
     * Flight from New York to Tel-Aviv departs at 10:50. Flight is full.
     * Flight from Tel-Aviv to Paris departs at 11:35. Flight is not full.
     */
    public String toString(){
        if(_noOfFlights == 0) return null;
        String str = "The flights for airport Tel-Aviv today are:\n";
        for(int i = 0; i < _noOfFlights; i++){
            str += "Flight from " + _flightsSchedule[i].getOrigin() + " to " + 
                _flightsSchedule[i].getDestination() + " departs at "
                + _flightsSchedule[i].getDeparture().toString() + ". Flight is ";
            if(_flightsSchedule[i].getIsFull()) str += "Full.\n";
            else str += "not Full.\n";
        }
        return str;
    }
    /**
     * Returns how many flights are full
     * @return how many flights are full
     */
    public int howManyFullFlights(){
        int count = 0;
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].getIsFull()) count++;
        }
        return count;
    }
    /**
     * Returns how many flights take off or land at a certain city
     * @param city the city to check how many flights take off or land from
     * @return how many flights take off or land at a certain city
     */
    public int howManyFlightsBetween (String city){
        int c1 = 0, c2 = 0;
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].getOrigin().equals(city)) c1++;
        }
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].getDestination().equals(city)) c2++;
        }
        return c1 + c2;
    }
    /**
     * Returns a string that represent the most popular destination
     * @return a string that represent the most popular destination or null if there are no flights in the schedule
     */
    public String mostPopularDestination(){
        if(_noOfFlights == 0) return null;
        int max = 0, index = 0;
        for(int i = 0; i < _noOfFlights; i++){
            int count = 0;
            for(int j = 0; j < _noOfFlights; j++){
                if(_flightsSchedule[i].getDestination().equals(_flightsSchedule[j].getDestination())) count++;
            }
            if(count > max){
                max = count;
                index = i;
            }
        }
        return _flightsSchedule[index].getDestination();
    }
    /**
     * Returns a Filght object with the most expensive ticket
     * @return a Filght object with the most expensive ticket
     */
    public Flight mostExpensiveTicket(){
        if(_noOfFlights == 0) return null;
        int max = 0, index = 0;
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].getPrice() > max){
                max = _flightsSchedule[i].getPrice();
                index = i;
            }
        }
        return _flightsSchedule[index];
    }
    /**
     * Returns a Filght object with the longest duration
     * @return a Filght object with the longest duration
     */
    public Flight longestFlight(){
        if(_noOfFlights == 0) return null;
        int max = 0, index = 0;
        for(int i = 0; i < _noOfFlights; i++){
            if(_flightsSchedule[i].getFlightDuration() > max){
                max = _flightsSchedule[i].getFlightDuration();
                index = i;
            }
        }
        return _flightsSchedule[index];
    }
}
